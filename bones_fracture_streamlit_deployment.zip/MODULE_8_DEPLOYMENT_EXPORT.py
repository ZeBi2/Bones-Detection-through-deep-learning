# ============================================================
# MODULE 8 — DEPLOYMENT EXPORT
# ============================================================
# This replaces the testing-focused Module 8.
# It exports the best trained model and all Streamlit artifacts.
# ============================================================

import os
import pickle
import shutil
import tensorflow as tf

from tensorflow.keras.applications.densenet import preprocess_input

MODEL_PATH = "/kaggle/working/best_bones_fracture_model.keras"
DEPLOY_DIR = "/kaggle/working/streamlit_deployment"

os.makedirs(DEPLOY_DIR, exist_ok=True)

if not os.path.exists(MODEL_PATH):
    raise FileNotFoundError(
        "best_bones_fracture_model.keras was not found at:\n"
        + MODEL_PATH
    )

print("Loading best model...")

model = tf.keras.models.load_model(
    MODEL_PATH,
    custom_objects={"preprocess_input": preprocess_input},
    compile=False,
    safe_mode=False
)

print("✓ Best model loaded.")

config = {
    "classes": ["fractured", "not_fractured"],
    "class_mapping": {
        "fractured": 0,
        "not_fractured": 1
    },
    "image_size": (224, 224),
    "color_mode": "rgb",
    "model_format": "keras",
    "preprocessing": (
        "DenseNet preprocess_input embedded in "
        "the saved model"
    )
}

with open(
    os.path.join(DEPLOY_DIR, "model_config.pkl"),
    "wb"
) as f:
    pickle.dump(
        config,
        f,
        protocol=pickle.HIGHEST_PROTOCOL
    )

with open(
    os.path.join(DEPLOY_DIR, "class_mapping.pkl"),
    "wb"
) as f:
    pickle.dump(
        config["class_mapping"],
        f,
        protocol=pickle.HIGHEST_PROTOCOL
    )

with open(
    os.path.join(DEPLOY_DIR, "image_config.pkl"),
    "wb"
) as f:
    pickle.dump(
        {
            "image_size": (224, 224),
            "color_mode": "rgb"
        },
        f,
        protocol=pickle.HIGHEST_PROTOCOL
    )

shutil.copy2(
    MODEL_PATH,
    os.path.join(
        DEPLOY_DIR,
        "best_bones_fracture_model.keras"
    )
)

with open(
    os.path.join(
        DEPLOY_DIR,
        "model_summary.txt"
    ),
    "w"
) as f:
    model.summary(
        print_fn=lambda line:
        f.write(line + "\n")
    )

print("\n" + "=" * 70)
print("MODULE 8 — DEPLOYMENT EXPORT COMPLETED")
print("=" * 70)

print("\nDeployment folder:")
print(DEPLOY_DIR)

print("\nGenerated files:")

for filename in sorted(
    os.listdir(DEPLOY_DIR)
):
    print("✓", filename)

print(
    "\nThe .keras file contains the actual trained "
    "neural-network weights."
)

print(
    "The PKL files contain deployment metadata/configuration."
)

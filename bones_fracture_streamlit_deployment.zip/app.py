import os
import pickle
import numpy as np
import streamlit as st
from PIL import Image
import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.applications.densenet import preprocess_input

APP_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(APP_DIR, "best_bones_fracture_model.keras")
CONFIG_PATH = os.path.join(APP_DIR, "model_config.pkl")

st.set_page_config(
    page_title="Bone Fracture Detection",
    page_icon="🦴",
    layout="centered"
)

@st.cache_resource
def load_artifacts():
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(
            "best_bones_fracture_model.keras was not found."
        )

    with open(CONFIG_PATH, "rb") as f:
        config = pickle.load(f)

    model = load_model(
        MODEL_PATH,
        custom_objects={"preprocess_input": preprocess_input},
        compile=False,
        safe_mode=False
    )
    return model, config

def prepare_image(image, img_size):
    image = image.convert("RGB")
    image = image.resize(tuple(img_size))
    arr = np.asarray(image, dtype=np.float32)
    arr = np.expand_dims(arr, axis=0)
    # The saved model contains the DenseNet preprocess_input Lambda,
    # so raw RGB pixels are passed to the model.
    return arr

st.title("🦴 Bone Fracture Detection")
st.write(
    "Upload an X-ray image to obtain the model's predicted class "
    "and confidence."
)

try:
    model, config = load_artifacts()
except Exception as e:
    st.error(f"Model loading failed: {e}")
    st.stop()

classes = config.get(
    "classes",
    ["fractured", "not_fractured"]
)
img_size = config.get("image_size", [224, 224])

uploaded_file = st.file_uploader(
    "Upload an X-ray image",
    type=["jpg", "jpeg", "png", "bmp", "tif", "tiff"]
)

if uploaded_file is not None:
    image = Image.open(uploaded_file).convert("RGB")

    st.image(
        image,
        caption="Uploaded X-ray",
        use_container_width=True
    )

    if st.button("Predict", type="primary"):
        with st.spinner("Analyzing image..."):
            x = prepare_image(image, img_size)
            probabilities = model.predict(x, verbose=0)[0]

            predicted_index = int(np.argmax(probabilities))
            predicted_class = classes[predicted_index]
            confidence = float(probabilities[predicted_index]) * 100

        st.subheader("Prediction")

        if predicted_class == "fractured":
            st.error(
                f"Prediction: **Fractured**\n\n"
                f"Confidence: **{confidence:.2f}%**"
            )
        else:
            st.success(
                f"Prediction: **Not Fractured**\n\n"
                f"Confidence: **{confidence:.2f}%**"
            )

        st.subheader("Class probabilities")

        for i, class_name in enumerate(classes):
            st.write(
                f"**{class_name.replace('_', ' ').title()}**: "
                f"{probabilities[i] * 100:.2f}%"
            )
            st.progress(float(probabilities[i]))

st.divider()

st.caption(
    "Research/educational prototype. This application is not a "
    "medical diagnostic device and should not be used as a substitute "
    "for professional radiological assessment."
)

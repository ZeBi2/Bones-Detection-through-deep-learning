import os
import pickle
import shutil
import tensorflow as tf
from tensorflow.keras.applications.densenet import preprocess_input

MODEL_PATH = "/kaggle/working/best_bones_fracture_model.keras"
OUTPUT_DIR = "/kaggle/working/streamlit_deployment"

os.makedirs(OUTPUT_DIR, exist_ok=True)

if not os.path.exists(MODEL_PATH):
    raise FileNotFoundError(
        f"Best model not found: {MODEL_PATH}"
    )

# Verify that the saved Keras model can be loaded using the
# same custom-object fix required during Module 3 testing.
model = tf.keras.models.load_model(
    MODEL_PATH,
    custom_objects={"preprocess_input": preprocess_input},
    compile=False,
    safe_mode=False
)

# Based on the independent-testing pipeline:
config = {
    "classes": ["fractured", "not_fractured"],
    "class_mapping": {
        "fractured": 0,
        "not_fractured": 1
    },
    "image_size": [224, 224],
    "color_mode": "rgb",
    "batch_size": 1,
    "model_format": "keras",
    "preprocessing": "DenseNet preprocess_input is embedded in the saved model Lambda layer",
    "model_input_dtype": "float32"
}

# Export metadata/config as PKL.
with open(
    os.path.join(OUTPUT_DIR, "model_config.pkl"),
    "wb"
) as f:
    pickle.dump(config, f, protocol=pickle.HIGHEST_PROTOCOL)

# Export class mapping separately as PKL.
with open(
    os.path.join(OUTPUT_DIR, "class_mapping.pkl"),
    "wb"
) as f:
    pickle.dump(
        config["class_mapping"],
        f,
        protocol=pickle.HIGHEST_PROTOCOL
    )

# Export image configuration separately as PKL.
with open(
    os.path.join(OUTPUT_DIR, "image_config.pkl"),
    "wb"
) as f:
    pickle.dump(
        {
            "image_size": (224, 224),
            "color_mode": "rgb"
        },
        f,
        protocol=pickle.HIGHEST_PROTOCOL
    )

# Copy the actual trained neural network.
shutil.copy2(
    MODEL_PATH,
    os.path.join(
        OUTPUT_DIR,
        "best_bones_fracture_model.keras"
    )
)

# Save a model summary for documentation/debugging.
with open(
    os.path.join(OUTPUT_DIR, "model_summary.txt"),
    "w"
) as f:
    model.summary(print_fn=lambda line: f.write(line + "\n"))

print("=" * 70)
print("STREAMLIT DEPLOYMENT EXPORT COMPLETED")
print("=" * 70)
print("Output:", OUTPUT_DIR)
print("")
print("Generated:")
print("1. best_bones_fracture_model.keras")
print("2. model_config.pkl")
print("3. class_mapping.pkl")
print("4. image_config.pkl")
print("5. model_summary.txt")
print("")
print("The .keras file contains the actual neural-network weights.")
print("PKL files contain deployment metadata/configuration.")

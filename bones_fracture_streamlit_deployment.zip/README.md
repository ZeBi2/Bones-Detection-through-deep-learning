# Bone Fracture Detection — Streamlit Deployment

## Project structure

Place these files together:

- `app.py`
- `best_bones_fracture_model.keras`
- `model_config.pkl`
- `class_mapping.pkl`
- `image_config.pkl`
- `requirements.txt`

## Model details

The deployment configuration follows the testing pipeline:

- Input size: 224 × 224
- Color: RGB
- Classes:
  - fractured
  - not_fractured
- DenseNet preprocessing is embedded in the saved Keras model.

## Important

The neural network itself should remain in `.keras` format. PKL is used for
metadata/configuration such as class mapping and image settings. Pickling
the entire TensorFlow/Keras neural network is not recommended because it is
fragile across TensorFlow/Keras versions.

## Local installation

```bash
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
```

Linux/macOS:

```bash
source .venv/bin/activate
```

Install:

```bash
pip install -r requirements.txt
```

Run:

```bash
streamlit run app.py
```

## Kaggle export

Run `export_deployment.py` in the Kaggle environment where
`/kaggle/working/best_bones_fracture_model.keras` exists.

It creates:

`/kaggle/working/streamlit_deployment/`

with the model and PKL deployment files.

## Streamlit deployment

Upload the complete project folder/repository to the deployment platform,
including the `.keras` model and PKL configuration files.
